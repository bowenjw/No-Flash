local colors = {
    Off ={r = 0, g = 0, b = 0, a = 0},
    White = {r = 1, g = 1, b = 1, a = 0},
    Blue = {r = 0, g = 0, b = 1, a = 0},
    Red = {r = 1, g = 0, b = 0, a = 0},
    Green = {r = 0, g = 1, b = 0, a = 0},
    Yellow = {r = 1, g = 0.8, b = 0, a = 0}
  }
local color_setting = settings.startup["nf-damage-hit-tint"].value
if  color_setting == "Off" then
    data.raw.character.character.damage_hit_tint = colors.Off
elseif color_setting == "White" then
    data.raw["character"]["character"].damage_hit_tint = colors.White
elseif color_setting == "Blue" then
    data.raw["character"]["character"].damage_hit_tint = colors.Blue
elseif color_setting == "Red" then
    data.raw["character"]["character"].damage_hit_tint = colors.Red
elseif color_setting == "Green" then
    data.raw["character"]["character"].damage_hit_tint = colors.Green
elseif color_setting == "Yellow" then
    data.raw["character"]["character"].damage_hit_tint = colors.Yellow
end