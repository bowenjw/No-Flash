data:extend({
    {
        type = "string-setting",
        name = "nf-damage-hit-tint",
        order = "a",
        setting_type = "startup",
        default_value = "Red",
        allowed_values = {"Off", "White", "Blue", "Red", "Green", "Yellow"}
    }
})